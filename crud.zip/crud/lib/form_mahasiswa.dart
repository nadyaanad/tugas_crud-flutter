import 'package:flutter/material.dart';

class FormMahasiswaPage extends StatefulWidget {
  final Map<String, String>? data;

  const FormMahasiswaPage({super.key, this.data});

  @override
  State<FormMahasiswaPage> createState() => _FormMahasiswaPageState();
}

class _FormMahasiswaPageState extends State<FormMahasiswaPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nama = TextEditingController();
  final TextEditingController _npm = TextEditingController();
  final TextEditingController _prodi = TextEditingController();
  final TextEditingController _hp = TextEditingController();
  final TextEditingController _alamat = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.data != null) {
      _nama.text = widget.data!['nama']!;
      _npm.text = widget.data!['npm']!;
      _prodi.text = widget.data!['prodi']!;
      _hp.text = widget.data!['hp']!;
      _alamat.text = widget.data!['alamat']!;
    }
  }

  void simpan() {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context, {
        'nama': _nama.text,
        'npm': _npm.text,
        'prodi': _prodi.text,
        'hp': _hp.text,
        'alamat': _alamat.text,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.data == null ? "Tambah Data" : "Edit Data"),
        backgroundColor: const Color(0xFF7D0A0A),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nama,
                decoration: const InputDecoration(labelText: "Nama"),
                validator: (v) => v!.isEmpty ? "Wajib diisi" : null,
              ),
              TextFormField(
                controller: _npm,
                decoration: const InputDecoration(labelText: "NPM"),
                validator: (v) => v!.isEmpty ? "Wajib diisi" : null,
              ),
              TextFormField(
                controller: _prodi,
                decoration: const InputDecoration(labelText: "Prodi"),
                validator: (v) => v!.isEmpty ? "Wajib diisi" : null,
              ),
              TextFormField(
                controller: _hp,
                decoration: const InputDecoration(labelText: "No HP"),
                validator: (v) => v!.isEmpty ? "Wajib diisi" : null,
              ),
              TextFormField(
                controller: _alamat,
                decoration: const InputDecoration(labelText: "Alamat"),
                validator: (v) => v!.isEmpty ? "Wajib diisi" : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: simpan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1D6F1F),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text("Simpan", style: TextStyle(fontSize: 16)),
              )
            ],
          ),
        ),
      ),
    );
  }
}
