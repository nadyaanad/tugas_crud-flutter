import 'package:flutter/material.dart';
import 'form_mahasiswa.dart';

class Halaman_Utama extends StatefulWidget {
  const Halaman_Utama({super.key});

  @override
  State<Halaman_Utama> createState() => _Halaman_UtamaState();
}

class _Halaman_UtamaState extends State<Halaman_Utama> {
  List<Map<String, String>> mahasiswaList = [];

  void tambahMahasiswa(Map<String, String> data) {
    setState(() {
      mahasiswaList.add(data);
    });
  }

  void editMahasiswa(int index, Map<String, String> data) {
    setState(() {
      mahasiswaList[index] = data;
    });
  }

  void hapusMahasiswa(int index) {
    setState(() {
      mahasiswaList.removeAt(index);
    });
  }

  void bukaForm({Map<String, String>? dataEdit, int? index}) async {
    final hasil = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FormMahasiswaPage(
          data: dataEdit,
        ),
      ),
    );

    if (hasil == null) return;

    if (dataEdit == null) {
      tambahMahasiswa(hasil);
    } else {
      editMahasiswa(index!, hasil);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CRUD Mahasiswa"),
        backgroundColor: const Color(0xFF7D0A0A),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromARGB(255, 29, 111, 31),
        onPressed: () => bukaForm(),
        child: const Icon(Icons.add),
      ),
      body: mahasiswaList.isEmpty
          ? const Center(
              child: Text(
                "Belum ada data",
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: mahasiswaList.length,
              itemBuilder: (context, index) {
                final m = mahasiswaList[index];
                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Nama: ${m['nama']}",
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Text("NPM: ${m['npm']}"),
                        Text("Prodi: ${m['prodi']}"),
                        Text("No HP: ${m['hp']}"),
                        Text("Alamat: ${m['alamat']}"),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                              onPressed: () =>
                                  bukaForm(dataEdit: m, index: index),
                              child: const Text("Edit"),
                            ),
                            TextButton(
                              onPressed: () => hapusMahasiswa(index),
                              child: const Text("Hapus",
                                  style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
